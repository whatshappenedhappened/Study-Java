It is one simple tic tac toe game.
enjoy!